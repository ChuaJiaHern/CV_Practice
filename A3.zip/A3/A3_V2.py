import numpy as np

def build_projection_matrix(world_pts, image_pts):
    A = []

    for (X, Y, Z), (u, v) in zip(world_pts, image_pts):
        Xh = np.array([X, Y, Z, 1.0])

        A.append([
            Xh[0], Xh[1], Xh[2], Xh[3],
            0, 0, 0, 0,
            -u * Xh[0], -u * Xh[1], -u * Xh[2], -u * Xh[3]
        ])

        A.append([
            0, 0, 0, 0,
            Xh[0], Xh[1], Xh[2], Xh[3],
            -v * Xh[0], -v * Xh[1], -v * Xh[2], -v * Xh[3]
        ])

    A = np.array(A)
    _, _, Vt = np.linalg.svd(A)

    P = Vt[-1].reshape(3, 4)

    # Normalize P so the last element is easier to read
    P = P / P[-1, -1]

    return P


def triangulate_point(P1, P2, pt1, pt2):
    u1, v1 = pt1
    u2, v2 = pt2

    A = np.array([
        u1 * P1[2] - P1[0],
        v1 * P1[2] - P1[1],
        u2 * P2[2] - P2[0],
        v2 * P2[2] - P2[1],
    ])

    _, _, Vt = np.linalg.svd(A)
    X = Vt[-1]
    X = X / X[3]

    return X[:3]


def rq_decomposition(A):
    Q, R = np.linalg.qr(np.flipud(A).T)

    R = np.flipud(R.T)
    R = np.fliplr(R)

    Q = Q.T
    Q = np.flipud(Q)

    return R, Q


def decompose_projection_matrix(P):
    M = P[:, :3]

    K, R = rq_decomposition(M)

    # Fix signs so focal lengths are positive
    T = np.diag(np.sign(np.diag(K)))
    K = K @ T
    R = T @ R

    # If determinant of R is negative, flip sign
    if np.linalg.det(R) < 0:
        R = -R
        K = -K

    # Normalize K so K[2,2] = 1
    K = K / K[2, 2]

    # Re-fix sign if needed
    if K[0, 0] < 0:
        K[:, 0] *= -1
        R[0, :] *= -1

    if K[1, 1] < 0:
        K[:, 1] *= -1
        R[1, :] *= -1

    p4 = P[:, 3]

    # Translation from world to camera frame
    t = np.linalg.inv(K) @ p4

    # Camera position in world frame
    C = -R.T @ t

    return K, R, t, C


def main():
    world_pts = np.array([
        [1.0, 2.0, 1.0],
        [0.0, 0.0, 1.0],
        [0.0, 3.0, 0.0],
        [1.0, 0.0, 1.0],
        [2.0, 1.0, 0.0],
        [0.0, 2.0, 1.0],
    ])

    cam1_pixels = np.array([
        [894, 487],
        [767, 232],
        [780, 640],
        [894, 232],
        [1060, 360],
        [767, 487],
    ])

    cam2_pixels = np.array([
        [494, 455],
        [554, 274],
        [346, 465],
        [614, 334],
        [612, 465],
        [433, 395],
    ])

    red_cam1 = np.array([906, 626])
    red_cam2 = np.array([423, 523])

    P1 = build_projection_matrix(world_pts, cam1_pixels)
    P2 = build_projection_matrix(world_pts, cam2_pixels)

    red_3d = triangulate_point(P1, P2, red_cam1, red_cam2)

    K1, R1, t1, C1 = decompose_projection_matrix(P1)
    K2, R2, t2, C2 = decompose_projection_matrix(P2)

    print("Projection Matrix P1:")
    print(P1)

    print("\nProjection Matrix P2:")
    print(P2)

    print("\nTriangulated Red 3D Coordinate:")
    print(red_3d)

    print("\nCamera 1 Intrinsic Matrix K1:")
    print(K1)

    print("\nCamera 1 Rotation Matrix R1:")
    print(R1)

    print("\nCamera 1 Translation Vector t1:")
    print(t1)

    print("\nCamera 1 XYZ Position in World Frame C1:")
    print(C1)

    print("\nCamera 2 Intrinsic Matrix K2:")
    print(K2)

    print("\nCamera 2 Rotation Matrix R2:")
    print(R2)

    print("\nCamera 2 Translation Vector t2:")
    print(t2)

    print("\nCamera 2 XYZ Position in World Frame C2:")
    print(C2)


if __name__ == "__main__":
    main()